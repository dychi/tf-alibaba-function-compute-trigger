'use strict';

// ロガーの設定
const logger = {
  info: console.log,
  error: console.error
};

import cbor from 'cbor';

/**
 * ハンドラ関数
 * @param {Buffer} event - イベントデータ
 * @param {Object} context - コンテキスト
 * @param {Function} callback - コールバック関数
 */
export const handler = async (event, context, callback) => {
  try {
    logger.info("イベントの処理を開始します");

    // イベントデータの解析
    const records = await cbor.decode(event);

    for (const record of records.Records || []) {
      logger.info("レコードを処理: %j", record);

      const pk = getPkValue(record, "PK");
      const email = getAttributeValue(record, "email");

      // PK と email の値を処理
      logger.info("PK: %s, email: %s", pk, email);
    }

    callback(null, 'OK');
  } catch (e) {
    logger.error("イベントの処理中にエラーが発生しました: %s", e.message);
    callback(null, 'Error');
  }
};

/**
 * 属性値を取得する
 * @param {Object} record - レコード
 * @param {string} column - 列名
 * @returns {any} 属性値
 */
const getAttributeValue = (record, column) => {
  const attrs = record.Columns || [];
  for (const x of attrs) {
    if (x.ColumnName === column) {
      return x.Value;
    }
  }
  return null;
};

/**
 * 主キー値を取得する
 * @param {Object} record - レコード
 * @param {string} column - 列名
 * @returns {any} 主キー値
 */
const getPkValue = (record, column) => {
  const attrs = record.PrimaryKey || [];
  for (const x of attrs) {
    if (x.ColumnName === column) {
      return x.Value;
    }
  }
  return null;
};